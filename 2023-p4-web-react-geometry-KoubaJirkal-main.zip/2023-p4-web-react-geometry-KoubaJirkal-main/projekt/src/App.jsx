import { useContext, useState } from 'react'
import './App.css'
import { AppContext } from './provider/geometryProvider';
import Shelf from './components/Shelf'

function App() {
  const [data, dispatch] = useContext(AppContext);
  //console.log(data.geometries[0][0].color);
  return (
    <>
      <Shelf></Shelf>


      <button onClick={() => dispatch({type: "Add", payload: {shape: 'rectangle', color: 'green', row: 0} })}>Přidat zelený čtverec na Row 0</button>
    </>
  )
}

export default App
