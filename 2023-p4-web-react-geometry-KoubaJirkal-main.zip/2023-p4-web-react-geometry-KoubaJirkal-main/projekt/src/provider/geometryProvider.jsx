import { v4 as randomUUID } from "uuid";
import { createContext, useReducer } from "react";

const initialState = {  
    boxName: 'box',
    geometries: [
        [
            { id: randomUUID(), shape: 'circle', color: 'red' },
            { id: randomUUID(), shape: 'rectangle', color: 'blue' },
            { id: randomUUID(), shape: 'triangle', color: 'green' },
        ],
        [
            { id: randomUUID(), shape: 'triangle', color: 'blue' },
            { id: randomUUID(), shape: 'circle', color: 'green' },
            { id: randomUUID(), shape: 'rectangle', color: 'red  ' },
        ],
        [
            { id: randomUUID(), shape: 'triangle', color: 'blue' },
            { id: randomUUID(), shape: 'rectangle', color: 'red' },
            { id: randomUUID(), shape: 'circle', color: 'green' },
        ],
    ],
};

const reducer = (state, action) => {
    console.log(action)
    switch (action.type){
    
        case "Add":{
            const karel = JSON.parse(JSON.stringify(state))
            
            console.log(karel.geometries[action.payload.row])
            karel.geometries[action.payload.row].push({id:randomUUID(), shape: action.payload.shape, color: action.payload.color})
            return karel;
        }

        case "Remove":{
            const karel = JSON.parse(JSON.stringify(state))
            console.log(action.payload)
            console.log(karel.geometries[action.payload.row])
            
            return state;
        }
        default:{return state}
    }
    
}


export const AppContext = createContext(initialState);

export const AppProvider = ({children}) => {
    const store = useReducer(reducer, initialState);
 
    return(
<AppContext.Provider value={store}>
            {children}
</AppContext.Provider>
    )
}