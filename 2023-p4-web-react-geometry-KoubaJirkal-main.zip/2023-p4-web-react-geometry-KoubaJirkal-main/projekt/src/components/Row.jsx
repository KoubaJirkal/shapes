import React from 'react';
import Geometry from './Geometry';
import { useContext } from 'react';
import { AppContext } from '../provider/geometryProvider';

const Row = ({id, list, rest}) => {

    const [data, dispatch] = useContext(AppContext);
    //console.log(list)
    return (
        <div className='karel123'>
            <h2>Row {id}</h2>
            {list.map((row, id, child) => { //console.log(row)
                 return <div key={id} onClick={() =>dispatch({type: "Remove", payload: {id: id}})}><Geometry key={id} id={row.id} shape={row.shape} color={row.color} ></Geometry></div>}

                 )}
        </div>
    );
};

export default Row;
 