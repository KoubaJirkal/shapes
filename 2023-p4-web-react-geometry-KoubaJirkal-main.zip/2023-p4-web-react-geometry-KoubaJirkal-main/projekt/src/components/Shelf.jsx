import React from 'react';
import { useContext } from 'react';
import { AppContext } from '../provider/geometryProvider';
import Row from './Row'

const Shelf = () => {
    const [data, dispatch] = useContext(AppContext);
    //console.log(data);
    return (
        <>
            <h1>Shelf</h1>
            {data.geometries.map((geometry, id, child) => {//console.log(geometry)
                 return <Row key={id} id={id} list={geometry}></Row>}
                )}
        </>
    );
};

export default Shelf;
