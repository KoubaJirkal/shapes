import React from 'react';

const Geometry = ({ id, shape, color }) => {
    let shapeElement = null;

    switch (shape) {
        case 'circle':
            shapeElement = <circle cx="50" cy="50" r="40" fill={color} />;
            break;
        case 'rectangle':
            shapeElement = <rect x="10" y="10" width="80" height="80" fill={color} />;
            break;
        case 'triangle':
            shapeElement = <polygon points="50,10 90,90 10,90" fill={color} />;
            break;
        default:
            break;
    }

    return (
        <svg data-id={id} width="100" height="100">
            {shapeElement}
        </svg>
    );
};

export default Geometry;
